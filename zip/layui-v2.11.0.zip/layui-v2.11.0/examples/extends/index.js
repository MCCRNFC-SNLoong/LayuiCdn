

layui.define(function(exports){

  exports('index', {
    title: 'index 扩展模块'
  });
});
