# Change Log

- [更新日志](https://layui.dev/docs/versions.html)

## 发行日志
- [Github](https://github.com/layui/layui/releases)
- [Gitee](https://gitee.com/layui/layui/releases)
