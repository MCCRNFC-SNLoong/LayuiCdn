layui.use(function(){
  var $ = layui.$;
  var layer = layui.layer;

  layer.msg(layui.v);
})