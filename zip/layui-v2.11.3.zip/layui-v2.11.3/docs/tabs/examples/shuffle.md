<div class="layui-tabs" lay-options="{closable: true}">
  <ul class="layui-tabs-header">
    <li lay-id="fff">Tab6</li>
    <li lay-id="eee">Tab5</li>
    <li lay-id="ccc">Tab3</li>
    <li lay-id="bbb">Tab2</li>
    <li lay-id="aaa">Tab1</li>
    <li lay-id="ddd">Tab4</li>
  </ul>
  <div class="layui-tabs-body">
    <div class="layui-tabs-item" lay-id="aaa">Tab Content-1</div>
    <div class="layui-tabs-item" lay-id="bbb">Tab Content-2</div>
    <div class="layui-tabs-item" lay-id="ccc">Tab Content-3</div>
    <div class="layui-tabs-item" lay-id="ddd">Tab Content-4</div>
    <div class="layui-tabs-item" lay-id="eee">Tab Content-5</div>
    <div class="layui-tabs-item" lay-id="fff">Tab Content-6</div>
  </div>
</div>

🔔 提示：即 tabs 能通过 `lay-id` 匹配对应的标签头和标签内容。

<!-- import layui -->
