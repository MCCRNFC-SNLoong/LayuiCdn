/**
 * test2
 */

layui.define(function(exports){
  exports('test2', {
    title: 'test2 扩展模块'
  })
});
