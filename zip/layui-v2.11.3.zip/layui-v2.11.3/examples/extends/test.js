/**
 * test
 */

layui.define(function(exports){
  exports('test', {
    title: 'test 扩展模块'
  })
});
