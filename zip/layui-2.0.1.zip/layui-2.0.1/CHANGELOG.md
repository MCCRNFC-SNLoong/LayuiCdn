
# 更新日志
* [2.0.0](http://www.layui.com/doc/base/changelog.html#2-0-0)
