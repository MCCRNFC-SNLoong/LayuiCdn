<pre class="layui-code" lay-options="{preview: true, text: {preview: '综合用法'}, layout: ['preview', 'code'], tools: ['full']}">
  <textarea>
{{- d.include("/MOD_NAME/examples/demo.md") }}
  </textarea>
</pre>

<h3 id="demo-NAME1" class="ws-anchor ws-bold">示例1</h3>

<pre class="layui-code" lay-options="{preview: true, layout: ['preview', 'code'], tools: ['full']}">
  <textarea>
{{- d.include("/MOD_NAME/examples/ex1.md") }}
  </textarea>
</pre>

<h3 id="demo-NAME2" class="ws-anchor ws-bold">示例2</h3>

<pre class="layui-code" lay-options="{preview: true, layout: ['preview', 'code'], tools: ['full']}">
  <textarea>
{{- d.include("/MOD_NAME/examples/ex2.md") }}
  </textarea>
</pre>
