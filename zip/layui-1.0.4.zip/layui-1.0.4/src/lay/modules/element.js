/**

 @Name：layui.element 常用元素操作
 @Author：贤心
 @License：LGPL
    
 */
 
layui.define('jquery', function(exports){
  "use strict";
  
  var $ = layui.jquery
  ,hint = layui.hint()
  ,device = layui.device()
  
  ,MOD_NAME = 'element', THIS = 'layui-this', SHOW = 'layui-show'
  
  ,Element = function(){
    this.config = {};
  };
  
  //全局设置
  Element.prototype.set = function(options){
    var that = this;
    $.extend(true, that.config, options);
    return that;
  };
  
  //表单事件监听
  Element.prototype.on = function(events, callback){
    return layui.onevent(MOD_NAME, events, callback);
  };
  
  //外部Tab新增
  Element.prototype.tabAdd = function(filter, options){
    var tabElem = $('.layui-tab[lay-filter='+ filter +']')
    ,titElem = tabElem.children('.layui-tab-title')
    ,contElem = tabElem.children('.layui-tab-content');
    titElem.append('<li>'+ (options.title||'unnaming') +'</li>');
    contElem.append('<div class="layui-tab-item">'+ (options.content||'') +'</div>');
    return this.init();
  };
  
  //外部Tab删除
  Element.prototype.tabDelete = function(filter, index){
    var tabElem = $('.layui-tab[lay-filter='+ filter +']')
    ,liElem = tabElem.children('.layui-tab-title').find('>li').eq(index);
    call.tabDelete(null, liElem);
    return this;
  };
  
  //外部Tab切换
  Element.prototype.tabChange = function(filter, index){
    var tabElem = $('.layui-tab[lay-filter='+ filter +']')
    ,liElem = tabElem.children('.layui-tab-title').find('>li').eq(index);
    call.tabClick(null, index, liElem);
    return this;
  };
  
  //基础事件体
  var call = {
    //Tab点击
    tabClick: function(e, index, liElem){
      var othis = liElem || $(this)
      ,index = index || othis.index()
      ,parents = othis.parents('.layui-tab')
      ,item = parents.children('.layui-tab-content').children('.layui-tab-item')
      ,filter = parents.attr('lay-filter');
      
      othis.addClass(THIS).siblings().removeClass(THIS);
      item.eq(index).addClass(SHOW).siblings().removeClass(SHOW);
      
      layui.event.call(this, MOD_NAME, 'tab('+ filter +')', {
        elem: parents
        ,index: index
      });
    }
    
    //Tab删除
    ,tabDelete: function(e, othis){
      var li = othis || $(this).parent(), index = li.index();
      var parents = li.parents('.layui-tab');
      var item = parents.children('.layui-tab-content').children('.layui-tab-item')
      
      if(li.hasClass(THIS)){
        if(li.next()[0]){
          call.tabClick.call(li.next()[0], null, index + 1);
        } else if(li.prev()[0]){
          call.tabClick.call(li.prev()[0], null, index - 1);
        }
      }
      
      li.remove();
      item.eq(index).remove();
    }
    
    //Tab自适应
    ,tabAuto: function(){
      var SCROLL = 'layui-tab-scroll', MORE = 'layui-tab-more', BAR = 'layui-tab-bar'
      , CLOSE = 'layui-tab-close', that = this;
      
      $('.layui-tab').each(function(){
        var othis = $(this)
        ,title = othis.children('.layui-tab-title')
        ,item = othis.children('.layui-tab-content').children('.layui-tab-item')
        ,STOPE = 'lay-stope="tabmore"'
        ,span = $('<span class="layui-unselect layui-tab-bar" '+ STOPE +'><i '+ STOPE +' class="layui-icon">&#xe61a;</i></span>');
        
        if(that === window && device.ie != 8){
          call.hideTabMore(true)
        }
        
        //允许关闭
        if(othis.attr('lay-allowClose')){
          if(!title.find('li').find('.'+CLOSE)[0]){
            var close = $('<i class="layui-icon layui-unselect '+ CLOSE +'">&#x1006;</i>');
            close.on('click', call.tabDelete);
            title.find('li').append(close);
          }
        }
        if(title.prop('scrollWidth') > title.outerWidth()+1){
          if(title.find('.'+BAR)[0]) return;
          title.append(span);
          span.on('click', function(e){
            title[this.title ? 'removeClass' : 'addClass'](MORE);
            this.title = this.title ? '' : '收缩';
          });
        } else {
          title.find('.'+BAR).remove();
        }
      });
    }
    //隐藏更多Tab
    ,hideTabMore: function(e){
      var tsbTitle = $('.layui-tab-title');
      if(e === true || $(e.target).attr('lay-stope') !== 'tabmore'){
        tsbTitle.removeClass('layui-tab-more');
        tsbTitle.find('.layui-tab-bar').attr('title','');
      }
    }
  };
  
  //初始化元素操作
  Element.prototype.init = function(type){
    var that = this, items = {
      
      //Tab选项卡
      tab: function(){
        call.tabAuto.call({});
      }
      
      //导航菜单
      ,nav: function(){
        var ELEM = '.layui-nav', ITEM = 'layui-nav-item', BAR = 'layui-nav-bar'
        ,TREE = 'layui-nav-tree', CHILD = 'layui-nav-child', MORE = 'layui-nav-more'
        ,TIME = 200, timer, timerMore, timeEnd, follow = function(bar, nav){
          var othis = $(this), child = othis.find('.'+CHILD);
          
          if(nav.hasClass(TREE)){
            bar.css({
              top: othis.position().top
              ,height: othis.children('a').height()
              ,opacity: 1
            });
          } else {
            child.addClass('layui-anim layui-anim-upbit');
            bar.css({
              left: othis.position().left + parseFloat(othis.css('marginLeft'))
              ,top: othis.position().top + othis.height() - 5
            });
            
            timer = setTimeout(function(){
              bar.css({
                width: othis.width()
                ,opacity: 1
              });
            }, device.ie && device.ie < 10 ? 0 : TIME);
            
            clearTimeout(timeEnd);
            if(child.css('display') === 'block'){
              clearTimeout(timerMore);
            }
            timerMore = setTimeout(function(){
              child.show()
              othis.find('.'+MORE).addClass(MORE+'d');
            }, 300);
          }
        }
        
        $(ELEM).each(function(){
          var othis = $(this)
          ,bar = $('<span class="'+ BAR +'"></span>')
          ,itemElem = othis.find('.'+ITEM);
          
          //Hover滑动效果
          if(!othis.find('.'+BAR)[0]){
            othis.append(bar);
            itemElem.on('mouseenter', function(){
              follow.call(this, bar, othis);
            }).on('mouseleave', function(){
              if(!othis.hasClass(TREE)){
                clearTimeout(timerMore);
                timerMore = setTimeout(function(){
                  othis.find('.'+CHILD).hide();
                  othis.find('.'+MORE).removeClass(MORE+'d');
                }, 300);
              }
            });
            othis.on('mouseleave', function(){
              clearTimeout(timer)
              timeEnd = setTimeout(function(){
                if(othis.hasClass(TREE)){
                  bar.css({
                    height: 0
                    ,top: bar.position().top + bar.height()/2
                    ,opacity: 0
                  });
                } else {
                  bar.css({
                    width: 0
                    ,left: bar.position().left + bar.width()/2
                    ,opacity: 0
                  });
                }
              }, TIME);
            });
          }
          
          //二级菜单
          itemElem.each(function(){
            var oitem = $(this), child = oitem.find('.'+CHILD);
            if(child[0] && !oitem.find('.'+MORE)[0]){
              oitem.children('a').append('<span class="'+ MORE +'"></span>');

              if(!othis.hasClass(TREE)) return;
              oitem.children('a').on('click', function(){
                var a = $(this);
                if(child.css('display') === 'none'){
                  oitem.addClass(ITEM+'ed');
                } else {
                  oitem.removeClass(ITEM+'ed');
                }
              });
            }
          });
        });
      }
      //面包屑
      ,breadcrumb: function(){
        var ELEM = '.layui-breadcrumb'
        
        $(ELEM).each(function(){
          var othis = $(this)
          ,separator = othis.attr('lay-separator') || '>'
          ,aNode = othis.find('a');
          if(aNode.find('.layui-box')[0]) return;
          aNode.each(function(index){
            if(index === aNode.length - 1) return;
            $(this).append('<span class="layui-box">'+ separator +'</span>');
          });
          othis.css('visibility', 'visible');
        });
      }
    };

    return layui.each(items, function(index, item){
      item();
    });
  };

  var element = new Element(), dom = $(document);
  element.init();
  
  var TITLE = '.layui-tab-title li';
  dom.on('click', TITLE, call.tabClick); //Tab切换
  dom.on('click', call.hideTabMore); //隐藏展开的Tab
  $(window).on('resize', call.tabAuto); //自适应
  
  exports(MOD_NAME, function(options){
    return element.set(options);
  });
});

