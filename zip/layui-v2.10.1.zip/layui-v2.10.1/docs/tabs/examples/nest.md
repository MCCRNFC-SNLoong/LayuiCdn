<div class="layui-tabs layui-tabs-card" lay-options="{headerMode:'normal'}">
  <ul class="layui-tabs-header">
    <li class="layui-this">标题1</li>
    <li>标题2</li>
    <li>标题3</li>
  </ul>
  <div class="layui-tabs-body" style="padding: 16px;">
    <div class="layui-tabs-item layui-show">
      <div class="layui-tabs" lay-options="{headerMode:'normal'}">
        <ul class="layui-tabs-header">
          <li class="layui-this">标题 1-1</li>
          <li>标题 1-2</li>
        </ul>
        <div class="layui-tabs-body">
          <div class="layui-tabs-item layui-show">1-1</div>
          <div class="layui-tabs-item">1-2</div>
        </div>
      </div>
    </div>
    <div class="layui-tabs-item">
      <div class="layui-tabs" lay-options="{headerMode:'normal'}">
        <ul class="layui-tabs-header">
          <li class="layui-this">标题 2-1</li>
          <li>标题 2-2</li>
          <li>标题 2-3</li>
        </ul>
        <div class="layui-tabs-body">
          <div class="layui-tabs-item layui-show">2-1</div>
          <div class="layui-tabs-item">2-2</div>
          <div class="layui-tabs-item">2-3</div>
        </div>
      </div>
    </div>
    <div class="layui-tabs-item">3</div>
    <div class="layui-tabs-item">4</div>
    <div class="layui-tabs-item">5</div>
  </div>
</div>

<!-- import layui -->
