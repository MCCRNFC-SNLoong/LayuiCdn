/**
 * test1
 */

layui.define(function(exports){
  exports('test1', {
    title: 'test1 扩展模块'
  })
});
